public class PrimeSum {
    // Función para verificar si un número es primo
    public static boolean isPrime(int num) {
        if (num <= 1) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }

    // Función para sumar los primos en el rango [a, b]
    public static int sumPrimesInRange(int a, int b) {
        int sum = 0;
        for (int i = Math.min(a, b); i <= Math.max(a, b); i++) {
            if (isPrime(i)) {
                sum += i;
            }
        }
        return sum;
    }

    // Ejemplo de uso
    public static void main(String[] args) {
        int a = 10, b = 20;
        System.out.println("Suma de primos entre " + a + " y " + b + ": " + sumPrimesInRange(a, b));
    }
}