public class Palindromo {
    public static boolean esPalindromo(String cadena) {
        cadena = cadena.toLowerCase().replace(" ", "");
        StringBuilder inversa = new StringBuilder();
        for (int i = cadena.length() - 1; i >= 0; i--) {
            inversa.append(cadena.charAt(i));
        }
        return cadena.equals(inversa.toString());
    }

    public static void main(String[] args) {
        String texto = "Anita lava la tina";
        if (esPalindromo(texto)) {
            System.out.println("'" + texto + "' es un palíndromo");
        } else {
            System.out.println("'" + texto + "' no es un palíndromo");
        }
    }
}