public class SumaDigitos {
    public static int sumaDigitos(int n) {
        int suma = 0;
        while (n > 0) {
            suma += n % 10;
            n /= 10;
        }
        return suma;
    }

    public static void main(String[] args) {
        int numero = 123;
        System.out.println("La suma de los dígitos de " + numero + " es " + sumaDigitos(numero));
    }
}